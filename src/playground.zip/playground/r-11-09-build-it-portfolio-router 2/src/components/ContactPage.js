import React from 'react';

const ContactPage = () => (
  <div>
    <h1>Contact Me</h1>
    <p>You can reach me at test@gmail.com</p>
  </div>
);

export default ContactPage;
